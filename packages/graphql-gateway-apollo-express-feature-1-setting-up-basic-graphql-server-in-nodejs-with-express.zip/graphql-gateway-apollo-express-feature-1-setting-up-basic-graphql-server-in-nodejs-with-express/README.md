# express-graphql-demo
Basic express GraphQL setup with mock data for testing graphql queries and mutations

Run development enviroment using yarn

```
yarn install
yarn run dev
```

or with npm

```
npm i
npm run dev
```

after that the graphiql can be accessed at http://localhost:3000/graphql.

