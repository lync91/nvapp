# Apollo + Typescript + Codegen + File split boilerplate

Run npm install and npm start to run the graphql application. <br/>
Graphql url is http://localhost:4000/graphql
