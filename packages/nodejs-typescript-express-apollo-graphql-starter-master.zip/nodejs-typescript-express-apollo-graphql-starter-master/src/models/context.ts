export interface Context {
  jwt?: String;
}
